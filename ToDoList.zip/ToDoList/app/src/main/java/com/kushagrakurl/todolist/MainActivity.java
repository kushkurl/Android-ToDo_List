//Kushagra Kurl A002469
//Jaskirat Kaur A00219135

package com.kushagrakurl.todolist;


import androidx.appcompat.app.AppCompatActivity;


import android.os.Bundle;

import android.view.View;

import android.widget.EditText;
import android.widget.ListView;


import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity {

    ListView listView;

    Map<String,Boolean> taskList;
    {
        taskList = new HashMap<String, Boolean>() {
            {
                put("Christmas Shopping", false);
                put("Decorate House", true);
                put("Buy Cake", false);
            }
        };
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        // initiate a ListView
        listView = (ListView) findViewById(R.id.listView);
        CustomAdapter customAdapter = new CustomAdapter(getApplicationContext(), taskList);
        listView.setAdapter(customAdapter);
    }



    public void onAddItem(View v) {
        EditText etNewItem = (EditText) findViewById(R.id.etNewItem);
        String itemText = etNewItem.getText().toString();
        taskList.put(itemText, false);
        etNewItem.setText("");

    }
}

